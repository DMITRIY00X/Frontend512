
// Рекурсивная функция

// function elevator(n) {
//     if (n == 0) {
//         document.writeln("Вы в подвале<br>");
//         return;
//     }
//     console.log(n);
//     elevator(n-1);
//     document.writeln(n + " ");
// }

// let n1 = prompt("На каком вы этаже: ", 5);
// elevator(n1);

// 5! = 1*2*3*4*5 = 120

let fact = prompt("Введите число для нахождения факториала: ");

function factorial(factor) {  
    if (factor <= 1) {
        return factor;
    }
    return factor * factorial(factor - 1);
}

document.writeln( "Факториал числа: " + "<span style = 'color: green;'>" + fact + "</span> " + " равен " + "<span style = 'color: green;'>" + factorial(fact)) + "</span> ";

